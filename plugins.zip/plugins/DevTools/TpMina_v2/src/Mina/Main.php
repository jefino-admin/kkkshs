<?php

namespace Mina;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$this->cfg = new Config($this->getDataFolder()."mina.yml", Config::YAML);
	}
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		switch($cmd->getName()){

    
			
			case "setmina":
			  $cfg = $this->cfg->getAll();
			 	if($this->cfg->exists("mina") && $sender->getX() == $cfg["mina"]["x"] && $sender->getY() == $cfg["mina"]["y"] && $sender->getZ() == $cfg["mina"]["z"] && $sender->getLevel()->getName() == $cfg["mina"]["world"]){
		  		  $sender->sendMessage("§bMina Ja Foi Setada Neste lugar!");
		  	  }else{
			    $this->cfg->set("mina", [
			    "x" => $sender->getX(),
	  		  "y" => $sender->getY(),
	  		  "z" => $sender->getZ(),
  			  "world" => $sender->getLevel()->getName(),
			  ]);
			    $this->cfg->save();
		  	  $sender->sendMessage("§bMina Foi setada x: §f".$sender->getFloorX()." §6y: §f".$sender->getFloorY()." §6z: §f".$sender->getFloorZ()." §6world: §f".$sender->getLevel()->getName());
			  }
		  break;
		  
		  case "unsetmina":
		    if(!$this->cfg->exists("mina")){
		    	$sender->sendMessage("§bA Mina Não foi Setada Ainda!");
		    }else{
		    	$this->cfg->remove("mina");
		    	$this->cfg->save();
		    	$sender->sendMessage("§bMina Foi Removida!");
		    }
		  break;
		  
		  case "mina":
		    $cfg = $this->cfg->getAll();
		    if(!$this->cfg->exists("mina")){
		    	$sender->sendMessage("§bMina Ainda Nao Foi Setada!");
		    }else{
		    	if($this->getServer()->loadLevel($cfg["mina"]["world"]) == false){
		    		$sender->sendMessage("§bMina não foi achado ou foi removido!");
		    	}else{
		    		$cfg = $this->cfg->getAll();
		    		$pos = new Position($cfg["mina"]["x"],$cfg["mina"]["y"],$cfg["mina"]["z"],$this->getServer()->getLevelByName($cfg["mina"]["world"]));
		    		$sender->teleport($pos);
		    		$sender->sendMessage("§bTeleportado para a §aMina");
              $sender->sendMessage("§fRede§6Full");
         
		    	}
		    }
		  break;	  
		  
		}
	}
}
