<?php
namespace Nicknames;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
class Main extends PluginBase implements Listener {
	# Plugin made by Kairus Dark Seeker(Twitter: @KairusDS)
	
	private $config;
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$nicknameCommand = new NicknameCommand($this);
		$this->getServer()->getCommandMap()->register($nicknameCommand->commandName, $nicknameCommand);
	}
}
